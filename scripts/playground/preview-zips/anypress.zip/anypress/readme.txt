=== AnyPress ===
Contributors: anypress
Requires at least: 7.1
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 0.7.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A block theme built to be edited by people and by AI agents.

== Description ==

Every colour, font size, space, radius and shadow is a named token in theme.json, so a page changes with the site's palette and fonts instead of keeping old values. Sections take their colours from section styles (Tint, Brand soft, Brand, Dark, Second brand, Card). Every pattern says what it is for, which helps both the pattern inserter and AI agents pick the right one.

Style variations: six colour palettes (Forest, Plum, Ocean, Charcoal and gold, Rose, Night) and four font pairings (Warm serif, Editorial, Sturdy, Friendly), in Appearance > Editor > Styles. Every palette keeps text at WCAG AA contrast or better in every section style.

Starter pages: home pages for trades and local services, food and drink, and classes and memberships, plus About, Services and Contact pages, a long sales page, an email signup page and a thank-you page. A links page (for the link in a social media bio) is there too. They appear when a new page is created.

Kits: fourteen sets designed for one kind of business each. A kit is a style variation, its own sections and a complete home page:

* Ridge, for trades and home services: condensed capitals, hi-vis yellow, flat colour panels and the phone number as the main action.
* Circuit, for electricians: one bright grotesk, deep electric blue with a yellow spark, rounded cards and pill buttons.
* Hearth, for cafés, bakeries and restaurants: a printed menu card with dotted lines to each price, olive and mustard.
* Still, for spas, therapists and studios: light serif type, full-screen photography and plenty of space.
* Ledger, for accountants, lawyers, consultants and agencies: a report layout, a strong sans for titles and deep teal.
* Parcel, for online shops and makers: a product photo beside the collection, a narrow serif for names, clay and cream.
* Chapter, for online courses, coaching and memberships: school yellow and ink blue, a curriculum that opens week by week.
* Gloss, for salons, barbers and beauty studios: a high-contrast serif, blush and oxblood, the price list with dotted lines.
* Commons, for chambers of commerce, associations, clubs and churches: events with date blocks, membership levels, navy and brick.
* Rep, for gyms and fitness studios: heavy italic capitals, acid lime, the weekly timetable as a table.
* Frame, for photographers, designers and architects: one big sentence, staggered work with numbered captions, black and cobalt.
* Keystone, for estate agents and realtors: listings with price and facts, a featured home, forest green and brass.
* Launch, for software products and startups: one grotesk at every size, features without icons, pricing and questions.
* Byline, for blogs, magazines and newsletters: a masthead between rules, the newest post large and the rest in a grid.

Apply the kit's style in Appearance > Editor > Styles, then start a page from the kit's home page. The kit's sections are in the inserter under "Kit: ...".

AnyPress Blocks: 32 shared sections any site can use, whatever its kit, in eight groups in the inserter (Heroes, About, Services and prices, Proof, Calls to action, Contact, Blog, Footers). They take the site's colours and fonts, so they match the kit in use.

Post outlines: starting structures for a how-to guide, a list post and a product review, in the inserter under "Post outlines" when writing a post.

== Copyright ==

AnyPress block theme, (C) 2026 AnyPress.
AnyPress is distributed under the terms of the GNU GPL version 3 or later.

This theme bundles the following third-party resources:

Figtree, Copyright 2022 The Figtree Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/figtree-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/figtree

Bricolage Grotesque, Copyright 2022 The Bricolage Grotesque Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/bricolagegrotesque-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/bricolagegrotesque

Fraunces, Copyright 2018 The Fraunces Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/fraunces-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/fraunces

Newsreader, Copyright 2020 The Newsreader Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/newsreader-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/newsreader

Archivo, Copyright 2020 The Archivo Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/archivo-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/archivo

Big Shoulders, Copyright 2019 The Big Shoulders Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/bigshoulders-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/bigshoulders

Public Sans, Copyright 2015 The Public Sans Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/publicsans-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/publicsans

Young Serif, Copyright 2023 The Young Serif Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/youngserif-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/youngserif

Source Serif 4, Copyright 2014 The Source Serif 4 Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/sourceserif4-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/sourceserif4

Libre Franklin, Copyright 2020 The Libre Franklin Project Authors
License: SIL Open Font License, 1.1 (assets/fonts/licenses/librefranklin-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/librefranklin

Instrument Serif, Copyright 2022 The Instrument Serif Project Authors (https://github.com/Instrument/instrument-serif)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/instrumentserif-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/instrumentserif

Instrument Sans, Copyright 2022 The Instrument Sans Project Authors (https://github.com/Instrument/instrument-sans)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/instrumentsans-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/instrumentsans

Bodoni Moda, Copyright 2020 The Bodoni Moda Project Authors (https://github.com/indestructible-type/Bodoni)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/bodonimoda-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/bodonimoda

Jost, Copyright 2020 The Jost Project Authors (https://github.com/indestructible-type)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/jost-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/jost

Crimson Pro, Copyright 2018 The Crimson Pro Project Authors (https://github.com/Fonthausen/CrimsonPro)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/crimsonpro-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/crimsonpro

Gloock, Copyright 2022 The Gloock Project Authors (https://github.com/duartp/gloock)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/gloock-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/gloock

Manrope, Copyright 2018 The Manrope Project Authors (https://github.com/googlefonts/manrope)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/manrope-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/manrope

Schibsted Grotesk, Copyright 2023 The Schibsted-Grotesk Project Authors (https://github.com/schibsted/schibsted-grotesk)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/schibstedgrotesk-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/schibstedgrotesk

Literata, Copyright 2017 The Literata Project Authors (https://github.com/googlefonts/literata)
License: SIL Open Font License, 1.1 (assets/fonts/licenses/literata-OFL.txt)
Source: https://github.com/google/fonts/tree/main/ofl/literata

Placeholder images in assets/images and screenshot.png were made for this theme and are GPLv3 or later.

== Changelog ==

= 0.7.0 =
* Phone numbers, email addresses, addresses and opening hours in the kits and the Contact details section are bound to the business's site details (AnyPress Blocks 0.3.0 or later): set them once and every page shows them. Without AnyPress Blocks they show their example text, as before.
* New templates: Wide page, Page with sidebar and Post with sidebar, with a Sidebar template part (search, latest posts, topics).

= 0.6.1 =
* New "Blank page" template (no header or footer) for landing pages.
* Image alt text in every pattern is escaped for HTML attributes (esc_attr_e), as Theme Check asks.

= 0.6.0 =
* New kit, Circuit, for electricians and electrical contractors: a full website with a home page, 12 starter pages (services, a service, about, reviews, service areas, an area, offers, booking, FAQ, careers, contact, thank you) and 23 sections, with a sticky header and call button, an offer popup, FAQ, reviews and work carousels, counters and a service-area map.
* Its sections are in the inserter under "Kit: Electricians (Circuit)".

= 0.5.0 =
* Ridge is now a full plumbing and heating website: 13 starter pages (services, a service, about, reviews, service areas, an area, offers, quote, FAQ, careers, contact, thank you) and 18 new sections, with a sticky header and call button, a newsletter popup, FAQ, reviews carousel, counters and a service-area map.
* New block styles: "Stays on screen" for groups (a sticky header) and "Lines between" for the FAQ accordion.
* Uses the AnyPress Blocks plugin (0.2.0 or later) for the popup, carousel, counters and map.

= 0.4.3 =
* Buttons on kit home pages now jump to their sections (Book, Menu, Pricing and others) instead of going nowhere.
* Fluent Forms and FluentCart buttons take the site's brand colour.
* Cover heroes with text at the bottom left now line up with the header.

= 0.4.2 =
* The theme now has its own repository and release zips: https://github.com/hamchowderr/anypress-theme
* Adds the theme screenshot shown under Appearance > Themes.

= 0.4.1 =
* AnyPress Blocks: the 32 sections that work with any kit, in eight groups in the inserter.

= 0.4.0 =
* Nine more kits: Parcel, Chapter, Gloss, Commons, Rep, Frame, Keystone, Launch and Byline.
* Everyday sections, more starter pages and post outlines.

= 0.3.0 =
* The first four kits: Ridge, Hearth, Still and Ledger.

= 0.2.0 =
* Patterns, starter pages, six colour palettes and four font pairings.

= 0.1.0 =
* First version.
